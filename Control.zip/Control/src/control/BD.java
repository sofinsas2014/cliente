
package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class BD {
public String db = "asistencia";
public String url = "jdbc:mysql://localhost/"+db;
public String user = "root";
public String pass = "";
Connection cn = null;

    public BD(){
       
        try{
            //Cargamos el driver MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //Creamos un enlace a la base de datos
            cn = DriverManager.getConnection(this.url, this.user, this.pass);
            JOptionPane.showMessageDialog(null, "Conexion Exitosa");
        }catch(Exception e){
              JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    
    
     public DefaultTableModel Mostrar(){
        
    DefaultTableModel modelo= new DefaultTableModel();
    modelo.addColumn("idasistencia");
    modelo.addColumn("usuario_idusuario");
    modelo.addColumn("planilla_idplanilla");
    modelo.addColumn("fecha_entrada");
    modelo.addColumn("fecha_salida");
    modelo.addColumn("valido");
    
    
    String sql= "SELECT * FROM asistenciaestudiante";
    String []datos = new String [6];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                modelo.addRow(datos);
                
            }
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        return modelo;
     }
     
     public void Actualizar(String Datos){
         try{
            
            String sql="UPDATE asistenciaestudiante SET fecha_entrada='"+Datos+"' WHERE idasistencia=3";
            Statement st = cn.createStatement();
            st.executeQuery(sql);
            JOptionPane.showMessageDialog(null,"Actualizo Con exito");
            
         } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            
        }
     }
     
}
