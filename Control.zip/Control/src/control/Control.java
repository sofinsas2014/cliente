
package control;


public class Control {
 public static BD BaseDatos=new BD();

    public static void main(String[] args) {
       
        FInicio b= new FInicio();
        b.mostrar();
        
        
        
    }
    
}
